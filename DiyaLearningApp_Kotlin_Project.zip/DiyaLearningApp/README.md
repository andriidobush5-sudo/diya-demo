# Дія — навчальний макет (Android / Kotlin)

Це стартовий навчальний Android-проєкт на Kotlin та Jetpack Compose. Він не є офіційним застосунком держави й не підключається до державних реєстрів.

## Як відкрити
1. Розпакуйте ZIP.
2. Відкрийте папку `DiyaLearningApp` в Android Studio.
3. Дочекайтеся Gradle Sync.
4. Під'єднайте Android-телефон із увімкненим USB debugging або запустіть емулятор.
5. Натисніть **Run**.

## Як зібрати APK
В Android Studio: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
Готовий debug APK Android Studio покаже через посилання **locate**.

Потрібен JDK 17 та Android SDK Platform 35. Якщо Android Studio запропонує оновити Gradle або Android Gradle Plugin, спершу спробуйте рекомендовану сумісну версію.

## Вміст
- Головна сторінка
- Демонстраційні картки
- Профіль
- Нижня навігація
- Помітні позначки «ЗРАЗОК» та пояснення про відсутність юридичної сили
